def test_generic():
    a = -1
    b = "ML"
    assert a == b