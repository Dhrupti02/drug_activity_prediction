
from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="its a drug activity prediction", 
    author="dhrupti02", 
    packages=find_packages(),
    license="MIT"
)